package test428.in.Package_0;
public class ClassId_1 {
  protected int fieldid_1=-2;
  private long fieldid_0=-1;
}
