package test881.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  long param){
    return param;
  }
  private long fieldid_1=2;
  protected int fieldid_0=-1;
}
