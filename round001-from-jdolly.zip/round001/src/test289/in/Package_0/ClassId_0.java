package test289.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(  long param){
    return param;
  }
  private int fieldid_1=-1;
}
