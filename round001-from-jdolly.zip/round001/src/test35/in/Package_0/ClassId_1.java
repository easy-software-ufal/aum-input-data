package test35.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  int param){
    return param;
  }
  public long methodid_0(  long param){
    if (fieldid_0 != fieldid_1)     return fieldid_0 + fieldid_1;
    return fieldid_1;
  }
  private int fieldid_1=2;
  protected long fieldid_0=-1;
}
