package test790.in.Package_0;
public class ClassId_1 {
  private long fieldid_1=0;
  protected int fieldid_0=2;
}
