package test882.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  long param){
    return param;
  }
  protected int fieldid_1=1;
}
