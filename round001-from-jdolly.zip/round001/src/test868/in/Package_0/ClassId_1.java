package test868.in.Package_0;
public class ClassId_1 {
  public long methodid_0(){
    return new ClassId_1().fieldid_1;
  }
  private int fieldid_1=-1;
  protected long fieldid_0=2;
}
