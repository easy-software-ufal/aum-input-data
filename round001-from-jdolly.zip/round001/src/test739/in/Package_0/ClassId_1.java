package test739.in.Package_0;
public class ClassId_1 {
  protected int fieldid_1=-1;
  private long fieldid_0=-1;
}
