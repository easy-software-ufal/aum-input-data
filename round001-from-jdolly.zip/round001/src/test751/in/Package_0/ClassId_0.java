package test751.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(){
    if (fieldid_1 <= fieldid_0)     return fieldid_1 / fieldid_0;
    return fieldid_1;
  }
  protected int fieldid_1=-2;
}
