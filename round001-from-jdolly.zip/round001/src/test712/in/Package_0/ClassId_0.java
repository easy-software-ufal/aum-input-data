package test712.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  protected long fieldid_1=2;
}
