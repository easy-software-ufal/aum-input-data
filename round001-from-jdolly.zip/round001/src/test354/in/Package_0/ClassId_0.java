package test354.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(){
    return this.fieldid_0;
  }
  private long fieldid_1=-1;
}
