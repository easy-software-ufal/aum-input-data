package test126.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return new ClassId_1().fieldid_1;
  }
  public long methodid_1(  int param){
    if (fieldid_1 < fieldid_0)     return fieldid_1 * fieldid_0;
    return fieldid_1;
  }
  protected long fieldid_0=-1;
  private int fieldid_1=2;
}
