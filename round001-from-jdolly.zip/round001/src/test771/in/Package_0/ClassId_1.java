package test771.in.Package_0;
public class ClassId_1 {
  protected long fieldid_0=0;
}
