package test282.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_1(  long param){
    return param;
  }
  protected int fieldid_0=2;
}
