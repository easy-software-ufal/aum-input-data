package test725.in.Package_0;
public class ClassId_1 {
  private long fieldid_0=1;
}
