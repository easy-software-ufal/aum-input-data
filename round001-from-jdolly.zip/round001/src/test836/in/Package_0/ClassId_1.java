package test836.in.Package_0;
public class ClassId_1 {
  public long methodid_0(){
    return new ClassId_1().fieldid_1;
  }
  public long methodid_1(  long param){
    if (fieldid_1 < fieldid_0)     return fieldid_1 + fieldid_0;
    return param;
  }
  private long fieldid_0=1;
  protected int fieldid_1=2;
}
