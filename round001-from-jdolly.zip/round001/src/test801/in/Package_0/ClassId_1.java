package test801.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  long param){
    return new ClassId_1().fieldid_1;
  }
  public long methodid_0(){
    if (fieldid_0 <= fieldid_1)     return fieldid_0++;
    return fieldid_0;
  }
  private int fieldid_1=2;
  protected long fieldid_0=1;
}
