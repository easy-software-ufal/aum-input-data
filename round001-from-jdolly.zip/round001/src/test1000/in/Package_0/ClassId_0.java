package test1000.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(  int param){
    return param;
  }
  public long methodid_0(  long param){
    if (fieldid_1 < fieldid_0)     return -fieldid_1;
    return param;
  }
  protected int fieldid_0=2;
}
