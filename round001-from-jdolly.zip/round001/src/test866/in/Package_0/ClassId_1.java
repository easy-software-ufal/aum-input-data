package test866.in.Package_0;
public class ClassId_1 {
  public long methodid_0(){
    return fieldid_1;
  }
  protected int fieldid_1=0;
}
