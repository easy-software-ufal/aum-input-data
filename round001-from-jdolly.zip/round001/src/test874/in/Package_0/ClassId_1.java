package test874.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return new ClassId_0().methodid_1();
  }
  private long fieldid_1=-1;
  protected int fieldid_0=2;
}
