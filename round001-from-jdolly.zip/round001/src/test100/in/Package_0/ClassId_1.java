package test100.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return new ClassId_0().methodid_1(2);
  }
  protected long fieldid_1=2;
}
