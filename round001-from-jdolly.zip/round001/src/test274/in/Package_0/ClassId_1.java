package test274.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  long param){
    if (fieldid_0 <= fieldid_1)     return ~fieldid_0;
    return fieldid_0;
  }
  protected int fieldid_1=-1;
  private long fieldid_0=-2;
}
