package test85.in.Package_0;
public class ClassId_1 {
  public long methodid_1(  int param){
    return param;
  }
  private int fieldid_1=0;
  protected long fieldid_0=-2;
}
