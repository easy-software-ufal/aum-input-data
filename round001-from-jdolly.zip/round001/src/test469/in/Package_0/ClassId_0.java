package test469.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(  long param){
    if (fieldid_0 > fieldid_1)     return fieldid_0 / fieldid_1;
    return param;
  }
  private long fieldid_1=1;
}
