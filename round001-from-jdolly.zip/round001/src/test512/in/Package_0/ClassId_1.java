package test512.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  int param){
    return ClassId_1.this.fieldid_1;
  }
  protected int fieldid_1=0;
  private long fieldid_0=1;
}
