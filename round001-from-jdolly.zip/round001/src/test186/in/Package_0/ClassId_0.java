package test186.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(  long param){
    return new ClassId_0().methodid_1(2);
  }
  public long methodid_1(  int param){
    if (fieldid_0 != fieldid_1)     return -fieldid_0;
    return fieldid_1;
  }
  private long fieldid_1=1;
}
