package test532.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return param;
  }
  protected int fieldid_1=2;
}
