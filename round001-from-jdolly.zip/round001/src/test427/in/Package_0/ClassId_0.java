package test427.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  private long fieldid_1=-1;
}
