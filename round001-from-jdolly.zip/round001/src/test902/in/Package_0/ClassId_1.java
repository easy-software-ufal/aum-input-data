package test902.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return 0;
  }
  private long fieldid_1=-1;
}
