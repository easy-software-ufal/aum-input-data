package test235.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_1(){
    if (fieldid_0 < fieldid_1)     return fieldid_0 - fieldid_1;
    return fieldid_0;
  }
  public long methodid_1(  long param){
    if (fieldid_0 >= fieldid_1)     return -fieldid_0;
    return param;
  }
  protected int fieldid_1=-1;
}
