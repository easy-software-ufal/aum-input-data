package test976.in.Package_0;
public class ClassId_1 {
  public long methodid_0(){
    return new ClassId_1().fieldid_1;
  }
  public long methodid_1(  long param){
    if (fieldid_1 > fieldid_0)     return fieldid_1 / fieldid_0;
    return fieldid_0;
  }
  protected int fieldid_0=2;
  private long fieldid_1=-2;
}
